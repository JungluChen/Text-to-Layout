import hashlib,json,math,re,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('examples/showcase/05_quarter_wave_resonator_6ghz/extraction/capacitance_input')
result={'scope':'read-only historical artifact audit; no new solver execution','files':{},'traces':{},'grid':{},'ports':[]}
files=['openems_model.m','openems_result.s2p','solver.stderr.txt','solver.stdout.txt','openems_run/model.xml']+[f'openems_run/port_{kind}{n}' for kind in ['ut','it'] for n in [1,2]]
for name in files:result['files'][name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
for kind in ['ut','it']:
 for n in [1,2]:
  name=f'port_{kind}{n}';s=(root/'openems_run'/name).read_text(); rows=[[float(x) for x in line.split()] for line in s.splitlines() if line.strip() and not line.startswith('%')]
  vals=[r[1] for r in rows]
  result['traces'][name]={'samples':len(rows),'nonfinite':sum(not math.isfinite(x) for x in vals),'nonzero':sum(x!=0 for x in vals),'max_abs':max(abs(x) for x in vals),'headers':[line for line in s.splitlines() if line.startswith('%')]}
xml=ET.parse(root/'openems_run/model.xml')
grid={axis:[float(x) for x in xml.find('.//'+axis+'Lines').text.split(',')] for axis in 'XYZ'}
result['grid']={axis:{'lines':len(v),'min':min(v),'max':max(v)} for axis,v in grid.items()}
for line in (root/'openems_model.m').read_text().splitlines():
 if 'AddLumpedPort(' not in line:continue
 brackets=re.findall(r'\[([^]]+)\]',line);start=[float(x) for x in brackets[1].split()];stop=[float(x) for x in brackets[2].split()]
 snapped=[[min(range(len(grid[a])),key=lambda i:abs(grid[a][i]-point[j])) for j,a in enumerate('XYZ')] for point in [start,stop]]
 result['ports'].append({'driver':line,'requested_start_um':start,'requested_stop_um':stop,'nearest_grid_indices':snapped,'nearest_grid_coordinates_um':[[grid[a][idx[j]] for j,a in enumerate('XYZ')] for idx in snapped],'nearest_grid_nonzero_dimensions':sum(a!=b for a,b in zip(*snapped))})
s=(root/'solver.stderr.txt').read_text();result['stderr_counts']={msg:s.count(msg) for msg in ['Lumped Element snapping failed','only a 1D/line integration is allowed','Not enough lines in direction: 2','Unused primitive']}
rows=[[float(x) for x in line.split()] for line in (root/'openems_result.s2p').read_text().splitlines() if line.strip() and not line.startswith(('#','!'))]
result['touchstone']={'samples':len(rows),'samples_with_nonfinite_s':sum(any(not math.isfinite(x) for x in row[1:]) for row in rows)}
print(json.dumps(result,indent=2,sort_keys=True,allow_nan=False))
