import subprocess,runpy
from textlayout.solvers.palace import benchmark_v017 as b
source=subprocess.check_output(['git','show','61f1b3ef60c6c4c1fca0c8919af956bc018af599:src/textlayout/solvers/palace/benchmark_v017.py'],text=True)
exec(compile(source,b.__file__,'exec'),b.__dict__)
runpy.run_path('docs/progress/evidence/2026-10-27-103608/probe.py.txt',run_name='__main__')
